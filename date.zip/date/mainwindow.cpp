#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDate>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->calculateButton, &QPushButton::clicked, this, &MainWindow::calculateDays);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::calculateDays()
{
    QDate startDate = QDate::fromString(ui->startDateEdit->text(), "dd.MM.yyyy");
    QDate endDate = QDate::fromString(ui->endDateEdit->text(), "dd.MM.yyyy");

    if (startDate.isValid() && endDate.isValid()) {
        int daysDifference = startDate.daysTo(endDate);

        // Створюємо рядок з результатом
        QString resultString = "Між " + startDate.toString("dd.MM.yyyy") +
                               " та " + endDate.toString("dd.MM.yyyy") +
                               " пройшло " + QString::number(daysDifference) + " днів.";

        // Виводимо результат у діалоговому вікні
        QMessageBox::information(this, "Результат", resultString);
    } else {
        // Виводимо повідомлення про некоректні дати
        QMessageBox::warning(this, "Помилка", "Введіть коректні дати!");
    }
}
